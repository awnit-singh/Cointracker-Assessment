package controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.json.JSONArray;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import service.BitcoinTrackerService;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

@RestController
@CrossOrigin
@RequestMapping("/")
@Api(tags = {""})
@RequiredArgsConstructor

public class BitcoinTrackerController {

    public BitcoinTrackerService bitcoinTrackerService;

    @ApiOperation(value = "Get the transfers based on the latest set of transactions", response = ArrayList.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved data"),
            @ApiResponse(code = 400, message = "Bad request. Please try again."),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you are trying to reach is not found")
    })
    @GetMapping(value = "/{productCode}", produces = "BigDecimal")
    public ResponseEntity<ArrayList<String>> getTransfers(Date from, Date to) {
        ArrayList<String> transactions = bitcoinTrackerService.getTransfers(from, to);
        if (transactions == null) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(transactions, HttpStatus.OK);
    }

// Ideally this function is automatically run whereby an API is used to pull the blockchain data (ie transaction list)
// This implementation relies on manual input of the transaction data. Separately, the get function is used to
// return the transactions
    @ApiOperation(value = "Post API receives the list of transactions that have occurred.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully inputted data"),
            @ApiResponse(code = 400, message = "Bad request. Please try again."),
            @ApiResponse(code = 401, message = "You are not authorized to edit the=is resource"),
            @ApiResponse(code = 403, message = "The resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you are trying to reach is not found")
    })
    @GetMapping(value = "/{transactionList}")
    public ResponseEntity<Boolean> setTransactionList(String transactionList) {
        if (bitcoinTrackerService.setTransactionList(transactionList)) {
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

    }

}
