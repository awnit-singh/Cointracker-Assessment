package service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

@RequiredArgsConstructor
@Service
public class BitcoinTrackerService {
    private final DatabaseConnector databaseConnector;
    public HashMap<String, Integer> totalItems = new HashMap<String, Integer>();

    public ArrayList<String> getTransfers(Date from, Date to) {
        ArrayList<String[]> transactions = databaseConnector.getLatestTransactions(from, to);
        if (transactions == null) {
            return null;
        }
        ArrayList<String> outputTransfers = new ArrayList<>();
        /*
        def detect_transfers(transactions):
            inTrans = {}
            storeListOut = []
            for transact in transactions:
            if transact[3] == 'in':
                if transact[4] in inTrans:
                    inTrans[transact[4]] += [transact]
                else:
                    inTrans[transact[4]] = [transact]
                for transact in transactions:
                    if transact[3] == 'out':
                        if transact[4] in inTrans:
                            numberOfTrans = len(inTrans[transact[4]])
                            if numberOfTrans != 0:
                                i = 0
                                for items in inTrans[transact[4]]:
                                    if items[2] == transact[2]:
                                        storeListOut.append([transact[0], inTrans[transact[4]][0][0]])
                                        # items.pop(i)
                                        inTrans[transact[4]] = inTrans[transact[4]].pop(i)
                                        i += 1
                                        return storeListOut
         */
        return outputTransfers;
    }

    public Boolean setTransactionList(String priceList) {
        //splitting the array using the end bracket in order to separate the list of inputs
        String [] splitedArray = StringUtils.split(priceList, ")");
        databaseConnector.setLatestTransactions(splitedArray);
        return true;
    }


}
