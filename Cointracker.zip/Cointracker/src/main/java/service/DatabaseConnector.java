package service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

@RequiredArgsConstructor
@Service
public class DatabaseConnector {
    //interface for SQL calls to get prices

    public void setLatestTransactions(String[] listOfTransactions) {
        for (String eachTransaction : listOfTransactions) {
            String[] eachTransactionData = eachTransaction.split(",");
            //SQL interface code to set transactions
            /*
            Database structure would be as follows:
            | DATE_TIME | TRANSACTION_ID | WALLET_ID | IS_IN* | BTC_VALUE | MATCHED** |
            data will get added consecutively in this database and will be sorted by DATE_TIME

            *IS_IN is true if 'in' and false if 'out'. I assume this will allow for faster search times
            **MATCHED is an alternative to removing matched transfers. By using a boolean for
            if the transaction has been paired it ensures we still have a record of it
             */
        }

    }

    public ArrayList<String[]> getLatestTransactions(Date from, Date to) {
        //SQL interface code to get transactions, of dates from - to
        ArrayList<String[]> transactions = new ArrayList<>();
        /*
        SELECT TRANSACTION_ID, WALLET_ID, IS_IN, BTC_VALUE
        FROM TRANSACTION TABLE
        WHERE MATCHED = FALSE
        AND DATE_TIME BETWEEN $from and $to
         */

        return transactions;
    }

}
