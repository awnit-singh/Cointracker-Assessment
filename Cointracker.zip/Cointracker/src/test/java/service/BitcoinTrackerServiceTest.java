package service;

import junit.framework.TestCase;
import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;


@RunWith(MockitoJUnitRunner.class)
public class BitcoinTrackerServiceTest extends TestCase {
//    stubbing output from database for the bitcointrackerservice
    @Mock
    private DatabaseConnector databaseConnector;
    @InjectMocks
    private BitcoinTrackerService bitcoinTrackerService;

    @BeforeAll
    public void setUp() {
        this.bitcoinTrackerService = new BitcoinTrackerService(databaseConnector);

        //setup test data here
        ArrayList<String[]> testList = new ArrayList<>();

        String a[] = {"tx_id_1", "wallet_id_1", "2020-01-01 15:30:20", "FALSE", "5.3"};
        String b[] = {"tx_id_2", "wallet_id_1", "2020-01-03 12:05:25", "FALSE", "3.2"};
        String c[] = {"tx_id_3", "wallet_id_2", "2020-01-01 15:30:20", "TRUE", "5.3"};
        String d[] = {"tx_id_4", "wallet_id_3", "2020-01-01 15:30:20", "TRUE", "5.3"};
        testList.add(a);
        testList.add(b);
        testList.add(c);
        testList.add(d);
                /*
                [
        ('tx_id_1', 'wallet_id_1', '2020-01-01 15:30:20 UTC', 'out', 5.3),  # 5.3 BTC was withdrawn out of 'wallet_id_1'
        ('tx_id_2', 'wallet_id_1', '2020-01-03 12:05:25 UTC', 'out', 3.2),  # 3.2 BTC was withdrawn out of 'wallet_id_1'
        ('tx_id_3', 'wallet_id_2', '2020-01-01 15:30:20 UTC', 'in', 5.3),   # 5.3 BTC was deposited into 'wallet_id_2'
        ('tx_id_4', 'wallet_id_3', '2020-01-01 15:30:20 UTC', 'in', 5.3),   # 5.3 BTC was deposited into 'wallet_id_3'
  ]
                 */
    }

    @Test
    public void testCaseOne() {

    }

}