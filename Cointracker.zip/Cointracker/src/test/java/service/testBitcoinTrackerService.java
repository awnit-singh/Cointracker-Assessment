package service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class testBitcoinTrackerService {
    // When using a database, the test would use mocked data to avoid making calls to the DB

    private DatabaseConnector databaseConnector;
    private BitcoinTrackerService terminal;


    @Test
    public void testCaseOne() {
//         = new PointOfSaleTerminal();
        terminal.setPricing("foo");

        terminal.scan("A");
        terminal.scan("A");

        assertEquals(terminal.calculateTotal(),new BigDecimal("2.50"));

    }


/*
    @Test
    public void filterProfileToActiveBRLocationsReturnsActiveProfile() {
        Set<String> activeBRLocations = Stream.of("USA", "UK").collect(Collectors.toSet());

        ProfileRequestDTO profileRequestDTO = new ProfileRequestDTO();

        SectionHeaderRequestDTO section = new SectionHeaderRequestDTO(null, 1L, ViewEnum.RELATED_PARTIES.getCode(), "**", "D", new HashSet<>());

        Set<SectionHeaderRequestDTO> sectionHashSet = new HashSet<>();
        sectionHashSet.add(section);

        ProfileHeaderRequestDTO profileHeaderRequestDTO = new ProfileHeaderRequestDTO();
        profileHeaderRequestDTO.setSections(sectionHashSet);

        profileRequestDTO.setProfileHeader(profileHeaderRequestDTO);

        kycMigrationService.filterProfileToActiveBRLocations(profileRequestDTO, activeBRLocations);

        assertTrue(profileRequestDTO.getProfileHeader().getSections().isEmpty());
    }

 */

}